<?php
define (DB_USER, "lija106");
define (DB_PASSWORD, "Lija@1234");
define (DB_DATABASE, "lifeteachesfoundation");
define (DB_HOST, "sumachost2.com");
?>