<?php
define (DB_USER, "val1");
define (DB_PASSWORD, "val2");
define (DB_DATABASE, "val3");
define (DB_HOST, "val4");
?>